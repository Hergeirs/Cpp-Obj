#include "TestApp.hpp"
#include <iostream>

int main()
{
    TestApp app;
    app.run();
}
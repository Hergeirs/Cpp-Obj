#include "TestApp.hpp"

int main ()
{
   TestApp app;
    app.run();
}
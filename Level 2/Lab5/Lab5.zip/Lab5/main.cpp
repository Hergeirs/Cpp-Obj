#include "Interface.hpp"

// sorry for the bloated main. only way i could think of to do this neatly.
int main()
{
	Interface().run();
}